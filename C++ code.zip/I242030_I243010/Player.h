#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Weapon.h"
#include <string>

class Player
{
private:
    sf::Vector2f position;
    sf::Vector2f velocity;
    float speed;
    float jumpSpeed;
    float gravity;
    bool isGrounded;
    bool isJumping;
    bool jumpKeyHeld;
    float jumpHoldTimer;
    float jumpHoldMax;
    bool airDashUsed;
    bool facingRight;
    
    int health;
    int maxHealth;
    int lives;
    bool isInvincible;
    float invincibilityTimer;
    
    bool canDash;
    float dashCooldown;
    float dashTimer;
    bool isDashing;
    sf::Vector2f dashDirection;
    
    sf::Sprite sprite;
    sf::Texture idleTexture[5];
    static const int MAX_RUN_FRAMES = 32; // Max frames we'll support without using std::vector
    sf::Texture runTextures[MAX_RUN_FRAMES];
    sf::Texture dashTextures[MAX_RUN_FRAMES];
    sf::Texture jumpTextures[MAX_RUN_FRAMES];
    int runTextureCount;
    int jumpTextureCount;
    int runCurrentFrame;
    float runAnimationTimer;
    float runAnimationSpeed;
    bool isRunning;
    bool prevIsRunning;
    int currentFrame;
    float animationTimer;
    float animationSpeed;
    float renderScaleX;
    float renderScaleY;
    bool waitingForInput;
    int dashTextureCount;
    int dashCurrentFrame;
    float dashAnimationTimer;
    float dashAnimationSpeed;
    
    Weapon* currentWeapon;
    
    int superMeter;
    bool superArtActive;
    float superArtTimer;
    
    sf::SoundBuffer jumpBuffer;
    sf::SoundBuffer dashBuffer;
    sf::SoundBuffer hitBuffer;
    sf::Sound jumpSound;
    sf::Sound dashSound;
    sf::Sound hitSound;
    
public:
    Player(float x, float y, const std::string& resourcesPath);
    ~Player();
    
    void update(float deltaTime);
    void draw(sf::RenderWindow& window);
    
    void moveLeft();
    void moveRight();
    void jump();
    void holdJump(bool held);
    void dash();
    void stopMoving();
    
    void takeDamage(int damage);
    void setWeapon(Weapon* weapon);
    Weapon* getWeapon() const;
    void addSuperCard();
    void consumeSuperCard();
    bool canUseSuperArt() const;
    void activateSuperArt();
    
    sf::Vector2f getPosition() const;
    sf::FloatRect getBounds() const;
    int getHealth() const;
    int getMaxHealth() const;
    int getLives() const;
    bool getIsInvincible() const;
    int getSuperMeter() const;
    void useSuperMeter(int amount);
    bool getSuperArtActive() const;
    
    void setPosition(float x, float y);
    void setGrounded(bool grounded);
    bool isGroundedState() const;
    void setRenderScale(float sx, float sy);
    void applyFrameTexture(const sf::Texture& tex);
    bool getWaitingForInput() const;
    void setWaitingForInput(bool waiting);
    bool isJumpKeyHeld() const;
    bool isJumpingState() const;
    bool getIsGrounded() const;
    float getVelocityY() const;
    bool isFacingRight() const { return facingRight; }
};
