#pragma once
#include <SFML/Graphics.hpp>
#include "Utils.h"

using namespace sf;

class Enemy
{
protected:
    Vector2f position;
    Vector2f velocity;
    int health;
    int maxHealth;
    int points;
    bool isActive;
    Sprite sprite;
    Texture texture;
    
public:
    Enemy(float x, float y, int hp, int pts);
    virtual ~Enemy();
    
    virtual void update(float deltaTime) = 0;
    virtual void draw(RenderWindow& window) = 0;
    virtual void takeDamage(int damage);
    
    Vector2f getPosition() const;
    int getHealth() const;
    bool getIsActive() const;
    void setActive(bool active);
    int getPoints() const;
    FloatRect getBounds() const;
};
