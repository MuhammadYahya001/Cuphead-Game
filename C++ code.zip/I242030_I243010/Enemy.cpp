#include "Enemy.h"
#include <string>

using namespace std;

Enemy::Enemy(float x, float y, int hp, int pts)
    : position(x, y), velocity(0, 0), health(hp), maxHealth(hp), points(pts), isActive(true),
      sprite(*getDummyTexture())
{
    string resourcesPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/";
    string enemyPaths[] = {
        resourcesPath + "Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/101193.png",
        resourcesPath + "Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/99298.png",
        resourcesPath + "Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/99003.png"
    };
    
    bool loaded = false;
    for (int i = 0; i < 3; i++)
    {
        if (texture.loadFromFile(enemyPaths[i]))
        {
            sprite = Sprite(texture);
            loaded = true;
            break;
        }
    }
    
    if (!loaded)
    {
        sprite = Sprite(*getDummyTexture());
    }
    
    sprite.setOrigin(Vector2f(16, 16));
    sprite.setScale(Vector2f(2.0f, 2.0f)); // Larger scale for better visibility
    sprite.setColor(Color(255, 150, 150)); // Slight red tint to make them stand out
}

Enemy::~Enemy()
{
}

void Enemy::takeDamage(int damage)
{
    health -= damage;
    if (health <= 0)
    {
        isActive = false;
    }
}

Vector2f Enemy::getPosition() const
{
    return position;
}

int Enemy::getHealth() const
{
    return health;
}

bool Enemy::getIsActive() const
{
    return isActive;
}

void Enemy::setActive(bool active)
{
    isActive = active;
}

int Enemy::getPoints() const
{
    return points;
}

FloatRect Enemy::getBounds() const
{
    return sprite.getGlobalBounds();
}
