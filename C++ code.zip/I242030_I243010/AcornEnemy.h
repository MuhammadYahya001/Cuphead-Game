#pragma once
#include "Enemy.h"
#include <SFML/Audio.hpp>

class AcornEnemy : public Enemy
{
public:
    enum AcornState { FLYING, DROPPING, FALLING };
    
private:
    AcornState currentState;
    float flyTimer;
    float horizontalSpeed;
    float targetX;  // Player X position to track
    
    // Animation frames - static to share across all acorns
    static const int MAX_FLY_FRAMES = 11;
    static const int MAX_DROP_FRAMES = 3;
    static const int MAX_FALL_FRAMES = 14;
    static sf::Texture* flyFrames;
    static sf::Texture* dropFrames;
    static sf::Texture* fallFrames;
    static int flyFrameCount;
    static int dropFrameCount;
    static int fallFrameCount;
    static bool texturesLoaded;
    static sf::SoundBuffer* flyBuffer;
    static sf::SoundBuffer* dropBuffer;
    static sf::Sound* flySound;
    static sf::Sound* dropSound;
    
    int currentFrame;
    float animTimer;
    float animSpeed;
    
public:
    AcornEnemy(float x, float y, float playerX);
    void update(float deltaTime) override;
    void updatePlayerPosition(float playerX);
    void draw(sf::RenderWindow& window) override;
    static void loadResources();
};
