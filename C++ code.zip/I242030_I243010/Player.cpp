#include "Player.h"
#include "Utils.h"
#include <cmath>
#include <cstdio>
#include <iostream>

using namespace sf;
using namespace std;

Player::Player(float x, float y, const string& resourcesPath)
    : position(x, y), velocity(0, 0), speed(200.0f), jumpSpeed(480.0f),
            gravity(800.0f), isGrounded(false), isJumping(false), facingRight(true),
            jumpHoldTimer(0.0f), jumpHoldMax(0.18f),
      health(3), maxHealth(3), lives(3), isInvincible(false), invincibilityTimer(0.0f),
      canDash(true), dashCooldown(0.0f), dashTimer(0.0f), isDashing(false),
      currentFrame(0), animationTimer(0.0f), animationSpeed(0.15f),
        currentWeapon(nullptr), superMeter(0), superArtActive(false), superArtTimer(0.0f),
      sprite(*getDummyTexture()), jumpSound(*getDummyBuffer()), dashSound(*getDummyBuffer()), hitSound(*getDummyBuffer()),
            renderScaleX(1.0f), renderScaleY(1.0f)
{
    // Initialize sprite with first texture after loading
    // Load idle frames from CupheadResources (fallback to existing player.png)
    string idleBase = resourcesPath + "CupheadResources/Idle/";
    for (int i = 0; i < 5; i++)
    {
        char path[512];
        snprintf(path, sizeof(path), "%scuphead_idle_%04d.png", idleBase.c_str(), i + 1);
        if (!idleTexture[i].loadFromFile(path))
        {
            // fallback to workspace player.png
            if (!idleTexture[i].loadFromFile(resourcesPath + "player.png"))
                idleTexture[i] = *getDummyTexture();
        }
    }
    
    sprite = Sprite(idleTexture[0]);
    // Use center origin consistent with applyFrameTexture
    Vector2u idleSize = idleTexture[0].getSize();
    if (idleSize.x > 0 && idleSize.y > 0)
    {
        sprite.setOrigin(Vector2f(idleSize.x / 2.0f, idleSize.y / 2.0f));
    }
    sprite.setScale(Vector2f(2.0f, 2.0f));
    // Ensure sprite position matches the player's logical position before first update
    sprite.setPosition(position);
    waitingForInput = false;
    jumpKeyHeld = false;
    jumpHoldTimer = 0.0f;
    
    string audioPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Audios-20251125T150841Z-1-001/Audios/";
    if (!jumpBuffer.loadFromFile(audioPath + "sfx_player_jump_01.wav"))
    {
        // Audio not found
    }
    else
    {
        jumpSound = Sound(jumpBuffer);
    }
    
    if (!dashBuffer.loadFromFile(audioPath + "sfx_player_dash_01.wav"))
    {
        // Audio not found
    }
    else
    {
        dashSound = Sound(dashBuffer); 
    }

    if (!hitBuffer.loadFromFile(audioPath + "sfx_player_hit_01.wav"))
    {
         // Audio not found
    }
    else
    {
         hitSound = Sound(hitBuffer);
    }

    // Load run frames preferring CupheadResources/Run/Normal, then fallback to movement/
    runTextureCount = 0;
    char rpath[512];
    // Try CupheadResources Run Normal
    string runBase1 = resourcesPath + "CupheadResources/Run/Normal/";
    for (int i = 1; i <= MAX_RUN_FRAMES; i++)
    {
        if (runTextureCount >= MAX_RUN_FRAMES) break;
        bool found = false;
        snprintf(rpath, sizeof(rpath), "%scuphead_run_%04d.png", runBase1.c_str(), i);
        if (runTextures[runTextureCount].loadFromFile(rpath)) { runTextureCount++; found = true; }
        if (!found)
        {
            // stop on first missing sequential frame to avoid excessive failed attempts
            break;
        }
    }

    // If none found, try alternate Run/Shooting naming
    if (runTextureCount == 0)
    {
        string runBase2 = resourcesPath + "CupheadResources/Run/Shooting/";
        for (int i = 1; i <= MAX_RUN_FRAMES; i++)
        {
            if (runTextureCount >= MAX_RUN_FRAMES) break;
            bool found = false;
            snprintf(rpath, sizeof(rpath), "%scuphead_run_shoot_%04d.png", runBase2.c_str(), i);
            if (runTextures[runTextureCount].loadFromFile(rpath)) { runTextureCount++; found = true; }
            if (!found)
            {
                // stop on first missing sequential frame
                break;
            }
        }
    }

    // Final fallback to bundled movement frames
    if (runTextureCount == 0)
    {
        for (int i = 1; i <= MAX_RUN_FRAMES; i++)
        {
            if (runTextureCount >= MAX_RUN_FRAMES) break;
            snprintf(rpath, sizeof(rpath), "%smovement/cuphead_run_shoot_%04d.png", resourcesPath.c_str(), i);
            if (runTextures[runTextureCount].loadFromFile(rpath))
            {
                runTextureCount++;
            }
            else
            {
                // stop on first missing sequential movement frame to keep order
                break;
            }
        }
    }

    // If still none loaded, fallback to idle textures
    if (runTextureCount == 0)
    {
        for (int i = 0; i < 5 && runTextureCount < MAX_RUN_FRAMES; i++)
        {
            runTextures[runTextureCount++] = idleTexture[i];
        }
    }
    runCurrentFrame = 0;
    runAnimationTimer = 0.0f;
    runAnimationSpeed = 0.08f;
    isRunning = false;
    prevIsRunning = false;
    // Dash animation init
    dashTextureCount = 0;
    dashCurrentFrame = 0;
    dashAnimationTimer = 0.0f;
    dashAnimationSpeed = 0.05f;
    // Load dash ground frames if present (several fallback filename patterns)
    string dashBase = resourcesPath + "CupheadResources/Dash/Ground/";
    // Load dash frames sequentially; stop on first missing sequential index to avoid excessive failed attempts
    for (int i = 1; i <= MAX_RUN_FRAMES; i++)
    {
        if (dashTextureCount >= MAX_RUN_FRAMES) break;
        bool found = false;
        snprintf(rpath, sizeof(rpath), "%scuphead_dash_%04d.png", dashBase.c_str(), i);
        if (dashTextures[dashTextureCount].loadFromFile(rpath)) { dashTextureCount++; found = true; }
        if (!found)
        {
            snprintf(rpath, sizeof(rpath), "%srun_dash_%04d.png", dashBase.c_str(), i);
            if (dashTextures[dashTextureCount].loadFromFile(rpath)) { dashTextureCount++; found = true; }
        }
        if (!found)
        {
            snprintf(rpath, sizeof(rpath), "%s%d.png", dashBase.c_str(), i-1);
            if (dashTextures[dashTextureCount].loadFromFile(rpath)) { dashTextureCount++; found = true; }
        }
        if (!found)
        {
            // stop on first missing sequential frame
            break;
        }
    }

    // If dash frames still not found, try single image files used as fallback
    if (dashTextureCount == 0)
    {
        string dashFallbacks[] = {
            resourcesPath + "player.png",
            resourcesPath + "ground.png",
            resourcesPath + "levelbackground.png"
        };
        for (int i = 0; i < (int)(sizeof(dashFallbacks)/sizeof(dashFallbacks[0])); i++)
        {
            if (dashTextures[dashTextureCount].loadFromFile(dashFallbacks[i]))
            {
                dashTextureCount = 1;
                break;
            }
        }
    }

    // Load jump frames (Cuphead Jump folder)
    jumpTextureCount = 0;
    for (int i = 0; i < MAX_RUN_FRAMES; i++) jumpTextures[i] = *getDummyTexture();
    Texture jumpTexturesLocal[MAX_RUN_FRAMES];
    string jumpBase = resourcesPath + "CupheadResources/Jump/Cuphead/";
    // Load jump frames sequentially and stop at first missing frame
    for (int i = 1; i <= MAX_RUN_FRAMES; i++)
    {
        if (jumpTextureCount >= MAX_RUN_FRAMES) break;
        bool found = false;
        snprintf(rpath, sizeof(rpath), "%scuphead_jump_%04d.png", jumpBase.c_str(), i);
        if (jumpTexturesLocal[jumpTextureCount].loadFromFile(rpath)) { jumpTextureCount++; found = true; }
        if (!found)
        {
            snprintf(rpath, sizeof(rpath), "%sjump_%04d.png", jumpBase.c_str(), i);
            if (jumpTexturesLocal[jumpTextureCount].loadFromFile(rpath)) { jumpTextureCount++; found = true; }
        }
        if (!found)
        {
            snprintf(rpath, sizeof(rpath), "%s%d.png", jumpBase.c_str(), i-1);
            if (jumpTexturesLocal[jumpTextureCount].loadFromFile(rpath)) { jumpTextureCount++; found = true; }
        }
        if (!found)
        {
            break;
        }
    }

    // If jump frames found, copy into the member jumpTextures array
    if (jumpTextureCount > 0)
    {
        for (int j = 0; j < jumpTextureCount && j < MAX_RUN_FRAMES; j++)
            jumpTextures[j] = jumpTexturesLocal[j];
    }
}

Player::~Player()
{
}

void Player::update(float deltaTime)
{
    auto setFrame = [this](const Texture& tex)
    {
        applyFrameTexture(tex);
    };
    
    if (!canDash && dashCooldown > 0.0f)
    {
        dashCooldown -= deltaTime;
        if (dashCooldown <= 0.0f)
        {
            canDash = true;
        }
    }

    // If we are waiting for the player to press any key (level-start idle),
    // freeze movement/physics and force the idle animation only.
    if (waitingForInput)
    {
        // Ensure no residual motion
        isDashing = false;
        isJumping = false;
        velocity.x = 0.0f;
        velocity.y = 0.0f;
        // Idle animation logic (same as idle branch)
        animationTimer += deltaTime;
        if (animationTimer >= animationSpeed)
        {
            animationTimer = 0.0f;
            currentFrame = (currentFrame + 1) % 5;
        }
        setFrame(idleTexture[currentFrame]);
        // Keep sprite positioned at logical player position
        sprite.setPosition(position);
        prevIsRunning = false;
        return;
    }
    
    if (isDashing)
    {
        dashTimer -= deltaTime;
        if (dashTimer <= 0.0f)
        {
            isDashing = false;
        }
        else
        {
            position.x += dashDirection.x * speed * 3.0f * deltaTime;
            position.y += dashDirection.y * speed * 3.0f * deltaTime;
        }
    }
    
    if (!isDashing)
    {
        if (!isGrounded)
        {
            // Variable jump height while jump key is held: apply reduced gravity for a short window
            if (isJumping && jumpKeyHeld && jumpHoldTimer < jumpHoldMax)
            {
                jumpHoldTimer += deltaTime;
                velocity.y += gravity * 0.35f * deltaTime; // gentler gravity while holding
            }
            else
            {
                velocity.y += gravity * deltaTime;
            }
        }
        else if (velocity.y > 0)
        {
            velocity.y = 0;
        }

        position.x += velocity.x * deltaTime;
        position.y += velocity.y * deltaTime;
    }
    
    if (isInvincible)
    {
        invincibilityTimer -= deltaTime;
        if (invincibilityTimer <= 0.0f)
        {
            isInvincible = false;
        }
    }
    
    if (superArtActive)
    {
        superArtTimer -= deltaTime;
        if (superArtTimer <= 0.0f)
        {
            superArtActive = false;
            superMeter = 0;
        }
    }
    
    // Choose animation based on state (dash, jump, run, idle)
    if (isDashing)
    {
        // Dash animation
        isRunning = false;
        dashAnimationTimer += deltaTime;
        if (dashTextureCount > 0 && dashAnimationTimer >= dashAnimationSpeed)
        {
            dashAnimationTimer = 0.0f;
            dashCurrentFrame = (dashCurrentFrame + 1) % dashTextureCount;
        }
        if (dashTextureCount > 0)
        {
            setFrame(dashTextures[dashCurrentFrame]);
        }
    }
    else if (!isGrounded && isJumping)
    {
        // Jump animation (simple single-frame or animated if available)
        isRunning = false;
        if (jumpTextureCount > 0)
        {
            static float jtTimer = 0.0f;
            jtTimer += deltaTime;
            
            static int jj = 0;
            int jframe = jj;
            if (jumpTextureCount > 1 && jtTimer >= 0.12f)
            {
                jtTimer = 0.0f;
                jj = (jj + 1) % jumpTextureCount;
                jframe = jj;
            }
            setFrame(jumpTextures[jframe]);
        }
    }
    else if (!isGrounded)
    {
        // In-air but not jumping (e.g. falling or jump released) -> show idle pose
        isRunning = false;
        setFrame(idleTexture[0]);
    }
    else
    {
        bool nowRunning = (fabs(velocity.x) > 5.0f) && !isDashing && isGrounded;
        bool wasRunning = prevIsRunning;
        if (nowRunning)
        {
            // Run animation
            isRunning = true;
            runAnimationTimer += deltaTime;
            if (!wasRunning)
            {
                // starting run: reset run animation
                runCurrentFrame = 0;
                runAnimationTimer = 0.0f;
                if (runTextureCount > 0)
                {
                    setFrame(runTextures[runCurrentFrame]);
                }
            }
            if (runAnimationTimer >= runAnimationSpeed && runTextureCount > 0)
            {
                runAnimationTimer = 0.0f;
                runCurrentFrame = (runCurrentFrame + 1) % runTextureCount;
                setFrame(runTextures[runCurrentFrame]);
            }
        }
        else
        {
            // Idle animation
            isRunning = false;
            if (wasRunning)
            {
                currentFrame = 0;
                animationTimer = 0.0f;
                setFrame(idleTexture[currentFrame]);
            }
            else
            {
                animationTimer += deltaTime;
                if (animationTimer >= animationSpeed)
                {
                    animationTimer = 0.0f;
                    currentFrame = (currentFrame + 1) % 5;
                    setFrame(idleTexture[currentFrame]);
                }
            }
        }
    }

    // update prev-running state
    prevIsRunning = isRunning;
    
    sprite.setPosition(position);
    if (velocity.x < 0)
        facingRight = false;
    else if (velocity.x > 0)
        facingRight = true;
    
    // Ensure final facing scale respects render scale
    if (!facingRight)
        sprite.setScale(Vector2f(-renderScaleX, renderScaleY));
    else
        sprite.setScale(Vector2f(renderScaleX, renderScaleY));
    
    if (isInvincible)
    {
        int flash = (int)(invincibilityTimer * 10.0f) % 2;
        sprite.setColor(flash == 0 ? Color::White : Color(255, 255, 255, 128));
    }
    else
    {
        sprite.setColor(Color::White);
    }
}

void Player::draw(RenderWindow& window)
{
    window.draw(sprite);
}

void Player::moveLeft()
{
    if (!isDashing)
    {
        velocity.x = -speed;
    }
}

void Player::moveRight()
{
    if (!isDashing)
    {
        velocity.x = speed;
    }
}

void Player::jump()
{
    // Trigger a jump if on ground and not dashing. Reset hold timer so holding the key extends the jump.
    if (isGrounded && !isJumping && !isDashing)
    {
        velocity.y = -jumpSpeed;
        isJumping = true;
        isGrounded = false;
        jumpHoldTimer = 0.0f;
        jumpSound.play();
    }
}

void Player::holdJump(bool held)
{
    // When the jump key is pressed/held, remember state. On press-edge, initiate jump if grounded.
    if (held)
    {
        if (!jumpKeyHeld)
        {
            if (isGrounded && !isDashing)
            {
                // start jump
                velocity.y = -jumpSpeed;
                isJumping = true;
                isGrounded = false;
                jumpHoldTimer = 0.0f;
                jumpSound.play();
            }
        }
        jumpKeyHeld = true;
    }
    else
    {
        // Released: stop holding; let gravity take over. Do not immediately cancel isJumping — landing will clear it.
        jumpKeyHeld = false;
    }
}

void Player::dash()
{
    // Dash only allowed while airborne (in Cuphead, air dash is used while jumping)
    if (canDash && !isDashing && !isGrounded)
    {
        isDashing = true;
        dashTimer = 0.2f;
        dashCooldown = 1.0f;
        canDash = false;
        
        if (velocity.x != 0.0f || velocity.y != 0.0f)
        {
            float len = sqrt(velocity.x * velocity.x + velocity.y * velocity.y);
            dashDirection.x = velocity.x / len;
            dashDirection.y = velocity.y / len;
        }
        else
        {
            dashDirection.x = facingRight ? 1.0f : -1.0f;
            dashDirection.y = 0.0f;
        }
        
        dashSound.play();
    }
}

void Player::stopMoving()
{
    if (!isDashing)
    {
        velocity.x = 0;
        // Immediately switch to idle pose when movement stops
        isRunning = false;
        prevIsRunning = false;
        currentFrame = 0;
        animationTimer = 0.0f;
        applyFrameTexture(idleTexture[currentFrame]);
    }
}

bool Player::getWaitingForInput() const
{
    return waitingForInput;
}

void Player::setWaitingForInput(bool waiting)
{
    waitingForInput = waiting;
    if (waiting)
    {
        // Ensure the player is visually idle while waiting for input
        stopMoving();
    }
}

bool Player::isJumpKeyHeld() const
{
    return jumpKeyHeld;
}

bool Player::isJumpingState() const
{
    return isJumping;
}

bool Player::getIsGrounded() const
{
    return isGrounded;
}

float Player::getVelocityY() const
{
    return velocity.y;
}

void Player::takeDamage(int damage)
{
    if (!isInvincible && !superArtActive)
    {
        health -= damage;
        if (health <= 0)
        {
            lives--;
            if (lives > 0)
            {
                health = maxHealth;
            }
        }
        isInvincible = true;
        invincibilityTimer = 2.0f;
        hitSound.play();
    }
}

void Player::setWeapon(Weapon* weapon)
{
    currentWeapon = weapon;
}

Weapon* Player::getWeapon() const
{
    return currentWeapon;
}

void Player::addSuperCard()
{
    if (superMeter < 5)
    {
        superMeter++;
    }
}

void Player::consumeSuperCard()
{
    if (superMeter > 0)
    {
        superMeter--;
    }
}

bool Player::canUseSuperArt() const
{
    return superMeter >= 5;
}

void Player::activateSuperArt()
{
    if (canUseSuperArt())
    {
        superArtActive = true;
        superArtTimer = 10.0f;
        superMeter = 0;
        isInvincible = true;
        invincibilityTimer = superArtTimer;
    }
}

Vector2f Player::getPosition() const
{
    return position;
}

FloatRect Player::getBounds() const
{
    return sprite.getGlobalBounds();
}

int Player::getHealth() const
{
    return health;
}

int Player::getMaxHealth() const
{
    return maxHealth;
}

int Player::getLives() const
{
    return lives;
}

bool Player::getIsInvincible() const
{
    return isInvincible;
}

int Player::getSuperMeter() const
{
    return superMeter;
}

void Player::useSuperMeter(int amount)
{
    superMeter -= amount;
    if (superMeter < 0) superMeter = 0;
}

bool Player::getSuperArtActive() const
{
    return superArtActive;
}

void Player::setPosition(float x, float y)
{
    position.x = x;
    position.y = y;
    // Keep sprite in sync for ground checks that run before update()
    sprite.setPosition(position);
}

void Player::setGrounded(bool grounded)
{
    isGrounded = grounded;
    if (grounded)
    {
        isJumping = false;
        velocity.y = 0;
    }
}

void Player::setRenderScale(float sx, float sy)
{
    renderScaleX = sx;
    renderScaleY = sy;
    // Apply immediately respecting facing direction
    if (!facingRight)
        sprite.setScale(Vector2f(-renderScaleX, renderScaleY));
    else
        sprite.setScale(Vector2f(renderScaleX, renderScaleY));
}

void Player::applyFrameTexture(const Texture& tex)
{
    sprite.setTexture(tex);
    Vector2u size = tex.getSize();
    if (size.x > 0 && size.y > 0)
    {
        // Use CENTER origin to prevent clipping on left/right sides
        sprite.setOrigin(Vector2f(size.x / 2.0f, size.y / 2.0f));
        float sx = facingRight ? renderScaleX : -renderScaleX;
        sprite.setScale(Vector2f(sx, renderScaleY));
    }
}

bool Player::isGroundedState() const
{
    return isGrounded;
}
