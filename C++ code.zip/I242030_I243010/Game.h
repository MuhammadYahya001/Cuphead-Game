#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Player.h"
#include "Enemy.h"
#include "Boss.h"
#include "Projectile.h"
#include "Utils.h"
#include "Platform.h"
#include "Peashooter.h"
#include "AcornEnemy.h"
#include "RegularEnemies.h"

enum class GameState
{
    TITLE,
    MENU,
    OVERWORLD,
    PLAYING,
    PAUSED,
    GAME_OVER,
    VICTORY
};

class Game
{
private:
    sf::RenderWindow window;
    GameState currentState;
    
    Player* player;
    Peashooter peashooter;
    
    static const int MAX_PROJECTILES = 500;
    Projectile projectiles[MAX_PROJECTILES];
    int projectileCount;
    
    static const int MAX_ENEMIES = 100;
    Enemy* enemies[MAX_ENEMIES];
    int enemyCount;
    
    Boss* boss;
    bool bossSpawned;
    
    sf::RectangleShape ground;
    sf::Vector2f groundPosition;
    float groundLevel;
    
    sf::View gameView;
    
    sf::Music backgroundMusic;
    sf::SoundBuffer shootBuffer;
    sf::SoundBuffer hitBuffer;
    sf::SoundBuffer enemyDeathBuffer;
    sf::Sound shootSound;
    sf::Sound hitSound;
    sf::Sound enemyDeathSound;
    
    sf::Font font;
    sf::Text scoreText;
    sf::Text livesText;
    sf::Text healthText;
    sf::Text superMeterText;
    sf::Text gameOverText;
    sf::Text victoryText;
    int score;
    
    float enemySpawnTimer;
    float bossSpawnTime;
    
    // Overworld members
    sf::Texture overworldBackgroundTexture;
    sf::Sprite overworldBackgroundSprite;
    sf::Image overworldMapImage;
    bool* overworldWalkableGrid;
    int overworldGridSize;
    int overworldGridCols;
    int overworldGridRows;
    sf::Texture overworldPlayerTexture;
    sf::Sprite overworldPlayerSprite;
    sf::Vector2f overworldPlayerPos;
    float overworldPlayerSpeed;
    std::string resourcesPath;

    // Per-level background (e.g. Forest Follies)
    sf::Texture levelBackgroundTexture;
    sf::Sprite levelBackgroundSprite;
    bool levelBackgroundLoaded;
    
    // Scrolling background system (triple-buffered for seamless repeat)
    // Use pointers because `sf::Sprite` has no default constructor in SFML 3.x
    sf::Sprite* levelBackgroundSprites[3];
    float backgroundScrollOffset;
    float backgroundWidth;
    
    // Platform obstacles system (no STL vectors allowed)
    static const int MAX_PLATFORMS = 50;
    Platform* platforms[MAX_PLATFORMS];
    int platformCount;

    // Title screen assets
    sf::Texture titleBackgroundTexture;
    sf::Sprite titleBackgroundSprite;
    static const int MAX_TITLE_FRAMES = 64;
    sf::Texture titleFrames[MAX_TITLE_FRAMES];
    int titleFrameCount;
    int titleCurrentFrame;
    float titleAnimTimer;
    float titleAnimSpeed;
    sf::Sprite titleLeftSprite;
    sf::Sprite titleRightSprite;
    sf::Music titleMusic;
    sf::Text pressAnyText;
    
    struct OverworldIcon
    {
        sf::Texture texture;
        sf::Sprite sprite;
        sf::Vector2f position;
        std::string name;
        int levelId;
        bool isActive;
        
        OverworldIcon() : sprite(*getDummyTexture()), position(0, 0), name(""), levelId(0), isActive(false) {}
    };
    
    static const int MAX_LEVEL_ICONS = 10;
    OverworldIcon levelIcons[MAX_LEVEL_ICONS];
    int levelIconCount;
    int overworldSelectedIndex;
    int currentPlayingLevel;
    bool levelCompleted[4];
    
    void handleInput(float deltaTime);
    void handleOverworldInput(float deltaTime);
    void updateGameplay(float deltaTime);
    void updateProjectiles(float deltaTime);
    void updateEnemies(float deltaTime);
    void checkCollisions();
    void spawnEnemy();
    void spawnBoss();
    void renderGameplay();
    void renderUI();
    void renderMenu();
    void renderTitle();
    void renderOverworld();
    void renderGameOver();
    void renderVictory();
    bool checkCollision(const sf::FloatRect& a, const sf::FloatRect& b) const;
    void resetGame();
    
public:
    Game();
    ~Game();
    void run();
};
