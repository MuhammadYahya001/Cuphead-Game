#pragma once
#include "Enemy.h"
#include <cmath>

class Boss : public Enemy
{
private:
    float attackTimer;
    float attackCooldown;
    int attackPhase;
    
public:
    Boss(float x, float y);
    void update(float deltaTime) override;
    void draw(RenderWindow& window) override;
    void takeDamage(int damage) override;
    void performAttack();
};
