#include "Game.h"
#include <sstream>
#include <cmath>
#include <ctime>
#include <iostream>

using namespace sf;
using namespace std;

Game::Game()
        : window(VideoMode(Vector2u(1280, 720)), "Cuphead - Don't Deal with the Devil"),
            currentState(GameState::TITLE),
      player(nullptr),
      projectileCount(0),
      enemyCount(0),
      boss(nullptr),
      bossSpawned(false),
      groundLevel(600.0f),
      score(0),
      enemySpawnTimer(0.0f),
      bossSpawnTime(30.0f),
      shootSound(*getDummyBuffer()), hitSound(*getDummyBuffer()), enemyDeathSound(*getDummyBuffer()),
    scoreText(*getDummyFont(), "", 24), livesText(*getDummyFont(), "", 24),
    healthText(*getDummyFont(), "", 24), superMeterText(*getDummyFont(), "", 24),
    gameOverText(*getDummyFont(), "", 48), victoryText(*getDummyFont(), "", 48),
        overworldBackgroundSprite(*getDummyTexture()), overworldPlayerSprite(*getDummyTexture()),
        levelBackgroundSprite(*getDummyTexture()), levelBackgroundLoaded(false),
        backgroundScrollOffset(0.0f), backgroundWidth(0.0f), platformCount(0),
        titleBackgroundSprite(*getDummyTexture()), titleLeftSprite(*getDummyTexture()), titleRightSprite(*getDummyTexture()),
            pressAnyText(*getDummyFont(), "", 28),
            overworldPlayerPos(140.0f, 170.0f), overworldPlayerSpeed(200.0f),
            titleFrameCount(0), titleCurrentFrame(0), titleAnimTimer(0.0f), titleAnimSpeed(0.12f),
            levelIconCount(0), overworldSelectedIndex(-1)
{
    // removed setFramerateLimit per restrictions
    srand((unsigned int)time(nullptr));
    
    // Initialize scrolling backgound
    for (int i = 0; i < 3; i++)
    {
        levelBackgroundSprites[i] = new Sprite(*getDummyTexture());
    }
    
    // Setup view
    gameView.setSize(Vector2f(1280, 720));
    gameView.setCenter(Vector2f(640, 360));
    
    // Setup ground
    ground.setSize(Vector2f(2000.0f, 50.0f));
    ground.setPosition(Vector2f(0, groundLevel));
    ground.setFillColor(Color(100, 50, 20));
    
    // Init arrays
    for (int i = 0; i < MAX_ENEMIES; i++)
    {
        enemies[i] = nullptr;
    }
    for (int i = 0; i < MAX_PLATFORMS; i++)
    {
        platforms[i] = nullptr;
    }
    
    // Load Fonts - Simplified paths
    string fontPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Fonts/CupheadVogue-Bold.otf";
    if (!font.openFromFile(fontPath.c_str()))
    {
        // Fallback to simple lookup
        font.openFromFile("resources/arial.ttf"); 
    }
    
    // UI Text Setup
    scoreText = Text(font, "", 24);
    scoreText.setFillColor(Color::White);
    scoreText.setPosition(Vector2f(20, 20));
    
    livesText = Text(font, "", 24);
    livesText.setFillColor(Color::White);
    livesText.setPosition(Vector2f(20, 60));
    
    healthText = Text(font, "", 24);
    healthText.setFillColor(Color::White);
    healthText.setPosition(Vector2f(20, 100));
    
    superMeterText = Text(font, "", 24);
    superMeterText.setFillColor(Color::Yellow);
    superMeterText.setPosition(Vector2f(20, 140));
    
    gameOverText = Text(font, "GAME OVER\nPress R to Restart", 48);
    gameOverText.setFillColor(Color::Red);
    gameOverText.setPosition(Vector2f(400, 300));
    
    victoryText = Text(font, "VICTORY!\nPress R to Restart", 48);
    victoryText.setFillColor(Color::Green);
    victoryText.setPosition(Vector2f(450, 300));
    
    // Audio Path Common Base
    string audioPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Audios-20251125T150841Z-1-001/Audios/";
    
    string musicPath = audioPath + "MUS_Tutorial.wav";
    if (!backgroundMusic.openFromFile(musicPath.c_str()))
    {
        musicPath = audioPath + "MUS_Frogs.wav";
        (void)backgroundMusic.openFromFile(musicPath.c_str());
    }
    if (backgroundMusic.getDuration().asSeconds() > 0)
    {
        backgroundMusic.setVolume(50.0f);
    }
    
    string shootPath = audioPath + "sfx_player_weapon_arc_fire_01.wav";
    if (shootBuffer.loadFromFile(shootPath.c_str()))
    {
        shootSound = Sound(shootBuffer);
    }
    string hitPath = audioPath + "sfx_player_hit_01.wav";
    if (hitBuffer.loadFromFile(hitPath.c_str()))
    {
        hitSound = Sound(hitBuffer);
    }
    
    // Overworld Setup
    resourcesPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/";
    
    // Load map - simplified logic
    string mapPath = resourcesPath + "map2.png";
    if (!overworldBackgroundTexture.loadFromFile(mapPath.c_str()))
    {
        string altPath = resourcesPath + "map.jpg";
        overworldBackgroundTexture.loadFromFile(altPath.c_str());
    }

    if (overworldBackgroundTexture.getSize().x > 0)
    {
        overworldBackgroundSprite = Sprite(overworldBackgroundTexture);
        Vector2u bgSize = overworldBackgroundTexture.getSize();
        if (bgSize.x > 0 && bgSize.y > 0)
        {
            overworldBackgroundSprite.setScale(Vector2f(1280.0f / bgSize.x, 720.0f / bgSize.y));
        }
    }

    // Walkability Grid REPLACED with simple logic
    overworldWalkableGrid = nullptr;
    
    // Overworld Player Sprite
    string pPath = resourcesPath + "player.png";
    if (overworldPlayerTexture.loadFromFile(pPath.c_str()))
    {
        overworldPlayerSprite = Sprite(overworldPlayerTexture);
        Vector2u playerSize = overworldPlayerTexture.getSize();
        if (playerSize.x > 0 && playerSize.y > 0)
        {
            overworldPlayerSprite.setOrigin(Vector2f(playerSize.x / 2.0f, playerSize.y / 2.0f));
            overworldPlayerSprite.setScale(Vector2f(1.5f, 1.5f));
        }
    }
    
    // Level Icons
    levelIconCount = 1;
    levelIcons[0].levelId = 1;
    levelIcons[0].name = "Forest Follies";
    levelIcons[0].position = Vector2f(980.0f, 420.0f);
    levelIcons[0].isActive = true;

    // Use simple player png as icon
    if (levelIcons[0].texture.loadFromFile(pPath.c_str()))
    {
        levelIcons[0].sprite = Sprite(levelIcons[0].texture);
        Vector2u iconSize = levelIcons[0].texture.getSize();
        if (iconSize.x > 0 && iconSize.y > 0)
        {
            levelIcons[0].sprite.setOrigin(Vector2f(iconSize.x / 2.0f, iconSize.y / 2.0f));
            levelIcons[0].sprite.setScale(Vector2f(0.5f, 0.5f));
        }
    }

    currentPlayingLevel = -1;
    for (int i = 0; i < 4; i++) levelCompleted[i] = false;
    
    // Title Screen
    string titleBgPath = resourcesPath + "Title/Background/title_screen_background.png";
    if (titleBackgroundTexture.loadFromFile(titleBgPath.c_str()))
    {
        titleBackgroundSprite = Sprite(titleBackgroundTexture);
        Vector2u tbgSize = titleBackgroundTexture.getSize();
        if (tbgSize.x > 0 && tbgSize.y > 0)
        {
            titleBackgroundSprite.setScale(Vector2f(1280.0f / tbgSize.x, 720.0f / tbgSize.y));
        }
    }

    // Title Frames
    titleFrameCount = 0;
    char tfpath[512];
    for (int i = 1; i <= MAX_TITLE_FRAMES; i++)
    {
        snprintf(tfpath, sizeof(tfpath), "%sTitle/Cuphead and Mugman/cuphead_title_screen_%04d.png", resourcesPath.c_str(), i);
        if (titleFrameCount >= MAX_TITLE_FRAMES) break;
        if (titleFrames[titleFrameCount].loadFromFile(tfpath))
        {
            titleFrameCount++;
        }
        else
        {
            break;
        }
    }
    if (titleFrameCount == 0)
    {
        titleFrames[0] = *getDummyTexture();
        titleFrameCount = 1;
    }

    titleLeftSprite = Sprite(titleFrames[0]);
    Vector2u tfSize = titleFrames[0].getSize();
    if (tfSize.x > 0 && tfSize.y > 0)
    {
        titleLeftSprite.setOrigin(Vector2f(tfSize.x / 2.0f, tfSize.y / 2.0f));
    }
    titleLeftSprite.setPosition(Vector2f(640.0f, 520.0f));
    titleLeftSprite.setScale(Vector2f(0.9f, 0.9f));

    // Title music
    string tMusicPath = resourcesPath + "Title/MUS_Intro_DontDealWithDevil_Vocal.wav";
    if (titleMusic.openFromFile(tMusicPath.c_str()))
    {
        titleMusic.setVolume(50.0f);
        titleMusic.play();
    }

    pressAnyText = Text(font, "Press any button", 28);
    pressAnyText.setFillColor(Color::White);
    FloatRect pat = pressAnyText.getGlobalBounds();
    pressAnyText.setPosition(Vector2f(640.0f - pat.size.x / 2.0f, 660.0f));

    levelBackgroundLoaded = false;
    levelBackgroundSprite = Sprite(*getDummyTexture());

    resetGame();
}

Game::~Game()
{
    delete player;
    delete boss;
    for (int i = 0; i < enemyCount; i++) delete enemies[i];
    for (int i = 0; i < platformCount; i++) delete platforms[i];
    if (overworldWalkableGrid) delete[] overworldWalkableGrid;
}

void Game::resetGame()
{
    delete player;
    player = nullptr;
    delete boss;
    boss = nullptr;
    
    for (int i = 0; i < enemyCount; i++)
    {
        delete enemies[i];
        enemies[i] = nullptr;
    }
    enemyCount = 0;
    projectileCount = 0;
    
    player = new Player((float)overworldPlayerPos.x, (float)overworldPlayerPos.y, resourcesPath);
    player->setWeapon(&peashooter);
    
    if (currentState == GameState::PLAYING)
    {
        player->setRenderScale(1.0f, 1.0f);
    }
    else
    {
        player->setRenderScale(0.6f, 0.6f);
    }
    
    bool waitForInput = (currentState == GameState::PLAYING);
    player->setWaitingForInput(waitForInput);
    
    levelBackgroundLoaded = false;
    if (currentPlayingLevel == 0)
    {
        // Simple manual check for background
        string bgPath = resourcesPath + "levelbackground.png";
        if (levelBackgroundTexture.loadFromFile(bgPath.c_str()))
        {
            levelBackgroundSprite = Sprite(levelBackgroundTexture);
            Vector2u bsz = levelBackgroundTexture.getSize();
            if (bsz.x > 0 && bsz.y > 0)
            {
                levelBackgroundSprite.setScale(Vector2f(1280.0f / (float)bsz.x, 720.0f / (float)bsz.y));
            }
            levelBackgroundLoaded = true;
        }
    }
    
    if (levelBackgroundLoaded && backgroundWidth == 0.0f)
    {
        Vector2u bgSize = levelBackgroundTexture.getSize();
        if (bgSize.x > 0 && bgSize.y > 0)
        {
            backgroundWidth = (float)bgSize.x;
            for (int i = 0; i < 3; i++)
            {
                if (levelBackgroundSprites[i]) delete levelBackgroundSprites[i];
                levelBackgroundSprites[i] = new Sprite(levelBackgroundTexture);
                float scaleY = 720.0f / (float)bgSize.y;
                levelBackgroundSprites[i]->setScale(Vector2f(scaleY, scaleY));
            }
            backgroundScrollOffset = 0.0f;
        }
    }
    
    score = 0;
    bossSpawned = false;
    enemySpawnTimer = 0.0f;
    bossSpawnTime = 30.0f;
    
    if (currentState == GameState::PLAYING && currentPlayingLevel == 0)
    {
        string forestMusicPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Audios-20251125T150841Z-1-001/Audios/MUS_ForestFollies.wav";
        if (backgroundMusic.openFromFile(forestMusicPath.c_str()))
        {
            backgroundMusic.setVolume(50.0f);
            backgroundMusic.play();
        }
    }
    else if (backgroundMusic.getDuration().asSeconds() > 0)
    {
        backgroundMusic.play();
    }
}

void Game::handleInput(float deltaTime)
{
    if (currentState == GameState::MENU)
    {
        static bool enterPressed = false;
        bool enterCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::Enter);
        if (enterCurrentlyPressed && !enterPressed)
        {
            currentState = GameState::OVERWORLD;
        }
        enterPressed = enterCurrentlyPressed;
        return;
    }
    
    if (currentState == GameState::OVERWORLD)
    {
        handleOverworldInput(deltaTime);
        return;
    }
    
    if (currentState == GameState::GAME_OVER || currentState == GameState::VICTORY)
    {
        static bool rPressed = false;
        bool rCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::R);
        if (rCurrentlyPressed && !rPressed)
        {
            resetGame();
            currentState = GameState::PLAYING;
        }
        rPressed = rCurrentlyPressed;
        return;
    }
    
    if (currentState != GameState::PLAYING)
        return;
    
    if (!player)
        return;
    
    static bool pPressed = false;
    bool pCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::P);
    if (pCurrentlyPressed && !pPressed)
    {
        if (currentState == GameState::PLAYING)
            currentState = GameState::PAUSED;
        else if (currentState == GameState::PAUSED)
            currentState = GameState::PLAYING;
    }
    pPressed = pCurrentlyPressed;
    
    if (currentState == GameState::PAUSED)
        return;
    
    if (player->getWaitingForInput())
    {
        bool anyKeyPressed = false;
        if (Keyboard::isKeyPressed(Keyboard::Key::A)) anyKeyPressed = true;
        if (Keyboard::isKeyPressed(Keyboard::Key::S)) anyKeyPressed = true;
        if (Keyboard::isKeyPressed(Keyboard::Key::D)) anyKeyPressed = true;
        if (Keyboard::isKeyPressed(Keyboard::Key::W)) anyKeyPressed = true;
        if (Keyboard::isKeyPressed(Keyboard::Key::Space)) anyKeyPressed = true;

        if (!anyKeyPressed)
        {
            player->stopMoving();
            return;
        }
        else
        {
            player->setWaitingForInput(false);
        }
    }

    bool movingLeft = Keyboard::isKeyPressed(Keyboard::Key::A) || Keyboard::isKeyPressed(Keyboard::Key::Left);
    bool movingRight = Keyboard::isKeyPressed(Keyboard::Key::D) || Keyboard::isKeyPressed(Keyboard::Key::Right);
    
    if (movingLeft)
        player->moveLeft();
    else if (movingRight)
        player->moveRight();
    else
        player->stopMoving();
    
    bool jumpHeld = Keyboard::isKeyPressed(Keyboard::Key::Space) || Keyboard::isKeyPressed(Keyboard::Key::W);
    player->holdJump(jumpHeld);

    static bool movePreviouslyPressed = false;
    bool moveCurrently = movingLeft || movingRight;
    if (moveCurrently && !movePreviouslyPressed && jumpHeld && player && !player->getIsGrounded())
    {
        player->dash();
    }
    movePreviouslyPressed = moveCurrently;
    
    static bool shiftPressed = false;
    bool shiftCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::LShift);
    if (shiftCurrentlyPressed && !shiftPressed)
    {
        player->dash();
    }
    shiftPressed = shiftCurrentlyPressed;

    static bool rollPressed = false;
    bool rollCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::S) || Keyboard::isKeyPressed(Keyboard::Key::Down);
    if (rollCurrentlyPressed && !rollPressed)
    {
        if (movingLeft || movingRight)
        {
            player->dash();
        }
    }
    rollPressed = rollCurrentlyPressed;
    
    Vector2f shootDir(1.0f, 0.0f);
    bool lockPressed = Keyboard::isKeyPressed(Keyboard::Key::LControl);
    
    if (lockPressed)
    {
        shootDir.x = 0.0f;
        shootDir.y = 0.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::Left)) shootDir.x -= 1.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::Right)) shootDir.x += 1.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::Up)) shootDir.y -= 1.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::Down)) shootDir.y += 1.0f;
        
        if (shootDir.x == 0.0f && shootDir.y == 0.0f)
            shootDir.x = 1.0f;
    }
    else
    {
        if (movingLeft) shootDir.x = -1.0f;
        if (movingRight) shootDir.x = 1.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::W) || Keyboard::isKeyPressed(Keyboard::Key::Up)) shootDir.y = -1.0f;
        if (Keyboard::isKeyPressed(Keyboard::Key::S) || Keyboard::isKeyPressed(Keyboard::Key::Down)) shootDir.y = 1.0f;
    }
    
    float len = sqrt(shootDir.x * shootDir.x + shootDir.y * shootDir.y);
    if (len > 0.01f)
    {
        shootDir.x /= len;
        shootDir.y /= len;
    }
    
    static float fireTimer = 0.0f;
    static const float FIRE_RATE = 0.15f; 
    
    bool xHeld = Keyboard::isKeyPressed(Keyboard::Key::X);
    fireTimer += deltaTime;
    
    if (xHeld && fireTimer >= FIRE_RATE)
    {
        fireTimer = 0.0f;
        Vector2f playerPos = player->getPosition();
        float bulletSpeed = 800.0f;
        
        if (shootDir.x == 0.0f && shootDir.y == 0.0f)
        {
            shootDir.x = player->isFacingRight() ? 1.0f : -1.0f;
        }
        
        if (projectileCount < MAX_PROJECTILES)
        {
            float bulletVelX = shootDir.x * bulletSpeed;
            float bulletVelY = shootDir.y * bulletSpeed;
            float spawnX = playerPos.x + shootDir.x * 40.0f;
            float spawnY = playerPos.y;
            projectiles[projectileCount] = Projectile(spawnX, spawnY, bulletVelX, bulletVelY, 1.0f, 5.0f, false);
            projectileCount++;
            shootSound.play();
        }
    }
    
    if (!xHeld)
    {
        fireTimer = FIRE_RATE;
    }
    
    static bool qPressed = false;
    bool qCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::Q);
    if (qCurrentlyPressed && !qPressed && player->canUseSuperArt())
    {
        player->activateSuperArt();
    }
    qPressed = qCurrentlyPressed;
}

void Game::handleOverworldInput(float deltaTime)
{
    bool movingLeft = Keyboard::isKeyPressed(Keyboard::Key::A) || Keyboard::isKeyPressed(Keyboard::Key::Left);
    bool movingRight = Keyboard::isKeyPressed(Keyboard::Key::D) || Keyboard::isKeyPressed(Keyboard::Key::Right);
    bool movingUp = Keyboard::isKeyPressed(Keyboard::Key::W) || Keyboard::isKeyPressed(Keyboard::Key::Up);
    bool movingDown = Keyboard::isKeyPressed(Keyboard::Key::S) || Keyboard::isKeyPressed(Keyboard::Key::Down);
    
    Vector2f moveDir(0.0f, 0.0f);
    if (movingLeft) moveDir.x -= 1.0f;
    if (movingRight) moveDir.x += 1.0f;
    if (movingUp) moveDir.y -= 1.0f;
    if (movingDown) moveDir.y += 1.0f;
    
    float len = sqrt(moveDir.x * moveDir.x + moveDir.y * moveDir.y);
    if (len > 0.01f)
    {
        moveDir.x /= len;
        moveDir.y /= len;

        // No complex grid logic - just bounds
        Vector2f delta(moveDir.x * overworldPlayerSpeed * deltaTime, moveDir.y * overworldPlayerSpeed * deltaTime);
        overworldPlayerPos += delta;

        if (player)
        {
            if (moveDir.x < 0.0f) player->moveLeft();
            else if (moveDir.x > 0.0f) player->moveRight();
            else player->stopMoving();

            player->setPosition(overworldPlayerPos.x, overworldPlayerPos.y);
            player->setGrounded(true);
            player->update(deltaTime);
        }
    }
    else
    {
        if (player) player->stopMoving();
    }
    
    if (player)
    {
        FloatRect pb = player->getBounds();
        float halfW = pb.size.x / 2.0f;
        float halfH = pb.size.y / 2.0f;
        float pad = 8.0f;
        float minX = halfW + pad;
        float maxX = 1280.0f - halfW - pad;
        float minY = halfH + pad;
        float maxY = 720.0f - halfH - pad;
        if (overworldPlayerPos.x < minX) overworldPlayerPos.x = minX;
        if (overworldPlayerPos.x > maxX) overworldPlayerPos.x = maxX;
        if (overworldPlayerPos.y < minY) overworldPlayerPos.y = minY;
        if (overworldPlayerPos.y > maxY) overworldPlayerPos.y = maxY;
    }
    
    overworldPlayerSprite.setPosition(overworldPlayerPos);
    
    overworldSelectedIndex = -1;
    for (int i = 0; i < levelIconCount; i++)
    {
        if (!levelIcons[i].isActive) continue;
            
        Vector2f dist = overworldPlayerPos - levelIcons[i].position;
        float distSquared = dist.x * dist.x + dist.y * dist.y;
        if (distSquared < 2500.0f)
        {
            overworldSelectedIndex = i;
            break;
        }
    }
    
    static bool enterPressed = false;
    bool enterCurrentlyPressed = Keyboard::isKeyPressed(Keyboard::Key::Enter);
    if (enterCurrentlyPressed && !enterPressed)
    {
        if (overworldSelectedIndex >= 0 && overworldSelectedIndex < levelIconCount)
        {
            if (levelIcons[overworldSelectedIndex].isActive)
            {
                currentPlayingLevel = overworldSelectedIndex;
                currentState = GameState::PLAYING;
                resetGame();
                if (player)
                {
                    player->setPosition(levelIcons[overworldSelectedIndex].position.x, groundLevel);
                    player->setGrounded(true);
                }
                bossSpawnTime = 10.0f * (overworldSelectedIndex + 1);
            }
        }
    }
    enterPressed = enterCurrentlyPressed;
}

void Game::renderOverworld()
{
    window.clear(Color(135, 206, 250));
    
    if (overworldBackgroundTexture.getSize().x > 0)
    {
        window.draw(overworldBackgroundSprite);
    }
    
    for (int i = 0; i < levelIconCount; i++)
    {
        if (!levelIcons[i].isActive) continue;

        float radius = 34.0f;
        CircleShape button(radius);
        button.setOrigin(Vector2f(radius, radius));
        button.setPosition(levelIcons[i].position);
        button.setFillColor(Color(200, 100, 50));
        button.setOutlineThickness(3.0f);
        button.setOutlineColor(Color::Black);
        window.draw(button);

        if (levelIcons[i].texture.getSize().x > 0)
        {
            levelIcons[i].sprite.setPosition(levelIcons[i].position);
            Vector2u tsize = levelIcons[i].texture.getSize();
            if (tsize.x > 0 && tsize.y > 0)
            {
                float dim = (float)tsize.x;
                if ((float)tsize.y > dim) dim = (float)tsize.y;
                float scale = (radius * 1.6f) / dim;
                levelIcons[i].sprite.setScale(Vector2f(scale, scale));
                window.draw(levelIcons[i].sprite);
            }
        }

        Text levelText(font, levelIcons[i].name, 18);
        levelText.setFillColor(Color::White);
        FloatRect textBounds = levelText.getGlobalBounds();
        levelText.setPosition(Vector2f(
            levelIcons[i].position.x - textBounds.size.x / 2.0f,
            levelIcons[i].position.y + radius + 8.0f
        ));
        window.draw(levelText);
    }
    
    if (overworldSelectedIndex >= 0 && overworldSelectedIndex < levelIconCount)
    {
        CircleShape highlight(45.0f);
        highlight.setFillColor(Color(255, 255, 0, 100)); // Yellow
        highlight.setOutlineThickness(3.0f);
        highlight.setOutlineColor(Color::Yellow);
        highlight.setOrigin(Vector2f(45.0f, 45.0f));
        highlight.setPosition(levelIcons[overworldSelectedIndex].position);
        window.draw(highlight);
    }
    
    if (player)
    {
        player->setPosition(overworldPlayerPos.x, overworldPlayerPos.y);
        player->draw(window);
    }
    else if (overworldPlayerTexture.getSize().x > 0)
    {
        overworldPlayerSprite.setPosition(overworldPlayerPos);
        window.draw(overworldPlayerSprite);
    }
    
    Text instrText(font, "Use WASD or Arrow Keys to move. Approach a level and press ENTER to start.", 20);
    instrText.setFillColor(Color::White);
    instrText.setPosition(Vector2f(20, 20));
    window.draw(instrText);
    
    window.display();
}

void Game::renderGameplay()
{
    window.clear(Color(135, 206, 235));
    window.setView(gameView);

    if (levelBackgroundLoaded && backgroundWidth > 0.0f)
    {
        Vector2f viewCenter = gameView.getCenter();
        float cameraX = viewCenter.x;
        Vector2u texSize = levelBackgroundTexture.getSize();
        float scaleY = 720.0f / (float)texSize.y;
        float scaledWidth = (float)texSize.x * scaleY;
        
        float offset = fmod(cameraX, scaledWidth);
        if (offset < 0) offset += scaledWidth;
        
        float startX = cameraX - 640.0f - offset;
        
        for (int i = 0; i < 3; i++)
        {
            float xPos = startX + (i * scaledWidth);
            levelBackgroundSprites[0]->setPosition(Vector2f(xPos, 0.0f));
            window.draw(*levelBackgroundSprites[0]);
        }
    }
    else
    {
        RectangleShape skyTop(Vector2f(2000.0f, 360.0f));
        skyTop.setFillColor(Color(173, 216, 230)); 
        skyTop.setPosition(Vector2f(0, 0));
        window.draw(skyTop);

        RectangleShape skyBottom(Vector2f(2000.0f, 360.0f));
        skyBottom.setFillColor(Color(135, 206, 250));
        skyBottom.setPosition(Vector2f(0, 360));
        window.draw(skyBottom);
    }
    
    for (int i = 0; i < projectileCount; i++)
    {
        if (projectiles[i].getIsActive())
        {
            projectiles[i].draw(window);
        }
    }
    
    for (int i = 0; i < enemyCount; i++)
    {
        if (enemies[i] && enemies[i]->getIsActive())
        {
            enemies[i]->draw(window);
        }
    }
    
    if (boss && boss->getIsActive())
    {
        boss->draw(window);
    }
    
    if (player)
    {
        player->draw(window);
    }
    
    window.setView(window.getDefaultView());
    renderUI();
    
    if (currentState == GameState::PAUSED)
    {
        RectangleShape overlay(Vector2f(1280, 720));
        overlay.setFillColor(Color(0, 0, 0, 150));
        window.draw(overlay);
        
        Text pauseText(font, "PAUSED", 48);
        pauseText.setFillColor(Color::White);
        pauseText.setPosition(Vector2f(550, 300));
        window.draw(pauseText);
    }
    
    window.display();
}

void Game::renderUI()
{
    ostringstream ss;
    ss << "Score: " << score;
    scoreText.setString(ss.str());
    window.draw(scoreText);
    
    ss.str("");
    ss << "Lives: " << (player ? player->getLives() : 0);
    livesText.setString(ss.str());
    window.draw(livesText);
    
    ss.str("");
    ss << "Health: " << (player ? player->getHealth() : 0) << "/" << (player ? player->getMaxHealth() : 0);
    healthText.setString(ss.str());
    window.draw(healthText);
    
    ss.str("");
    ss << "Super: ";
    int superMeter = player ? player->getSuperMeter() : 0;
    for (int i = 0; i < 5; i++)
    {
        ss << (i < superMeter ? "X" : "O");
    }
    superMeterText.setString(ss.str());
    window.draw(superMeterText);
}

void Game::renderGameOver()
{
    window.clear(Color::Black);
    window.draw(gameOverText);
    window.display();
}

void Game::renderVictory()
{
    window.clear(Color(50, 150, 50));
    window.draw(victoryText);
    window.display();
}

void Game::run()
{
    // Use manual timer logic instead of SFML Clock
    clock_t lastTime = clock();
    
    while (window.isOpen())
    {
        clock_t now = clock();
        float deltaTime = (float)(now - lastTime) / CLOCKS_PER_SEC;
        lastTime = now;

        // Cap deltaTime to avoid huge jumps
        if (deltaTime > 0.1f) deltaTime = 0.1f;
        
        while (auto event = window.pollEvent())
        {
            if (event->is<Event::Closed>())
            {
                window.close();
            }

            if (currentState == GameState::TITLE)
            {
                if (event->is<Event::KeyPressed>() || event->is<Event::MouseButtonPressed>())
                {
                    if (titleMusic.getStatus() == SoundSource::Status::Playing)
                        titleMusic.stop();

                    currentState = GameState::OVERWORLD;
                    for (int ei = 0; ei < enemyCount; ei++)
                    {
                        delete enemies[ei];
                        enemies[ei] = nullptr;
                    }
                    enemyCount = 0;
                    projectileCount = 0;
                    if (boss)
                    {
                        delete boss;
                        boss = nullptr;
                        bossSpawned = false;
                    }
                    if (backgroundMusic.getDuration().asSeconds() > 0)
                        backgroundMusic.play();
                }
            }
        }
        
        handleInput(deltaTime);
        
        if (backgroundMusic.getStatus() == SoundSource::Status::Stopped && backgroundMusic.getDuration().asSeconds() > 0)
        {
            backgroundMusic.play();
        }
    
        if (currentState == GameState::TITLE)
        {
            titleAnimTimer += deltaTime;
            if (titleAnimTimer >= titleAnimSpeed && titleFrameCount > 0)
            {
                titleAnimTimer = 0.0f;
                titleCurrentFrame = (titleCurrentFrame + 1) % titleFrameCount;
            }
        }
    
        if (currentState == GameState::PLAYING)
        {
            updateGameplay(deltaTime);
        }
        
        if (currentState == GameState::TITLE)
        {
            renderTitle();
        }
        else if (currentState == GameState::MENU)
        {
            renderMenu();
        }
        else if (currentState == GameState::OVERWORLD)
        {
            renderOverworld();
        }
        else if (currentState == GameState::PLAYING || currentState == GameState::PAUSED)
        {
            renderGameplay();
        }
        else if (currentState == GameState::GAME_OVER)
        {
            renderGameOver();
        }
        else if (currentState == GameState::VICTORY)
        {
            renderVictory();
        }
    }
}
