#include "Weapon.h"

Weapon::Weapon(float fireRate, float damage)
    : fireRate(fireRate), damage(damage), timeSinceLastShot(0.f), canFireFlag(true)
{
}

Weapon::~Weapon()
{
}

float Weapon::getDamage() const
{
    return damage;
}

float Weapon::getFireRate() const
{
    return fireRate;
}

void Weapon::update(float deltaTime)
{
    timeSinceLastShot += deltaTime;
    if (timeSinceLastShot >= 1.0f / fireRate)
    {
        canFireFlag = true;
    }
}
