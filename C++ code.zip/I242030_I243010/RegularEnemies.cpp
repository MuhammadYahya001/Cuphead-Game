#include "RegularEnemies.h"
#include <cmath>

SimpleEnemy::SimpleEnemy(float x, float y)
    : Enemy(x, y, 3, 100), speed(80.0f), directionX(-1.0f), moveTimer(0.0f)
{
    if (texture.loadFromFile("c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/113172.png"))
    {
        sprite = Sprite(texture);
    }
    else
    {
        sprite = Sprite(*getDummyTexture());
    }
    sprite.setOrigin(Vector2f(12, 12));
    sprite.setScale(Vector2f(1.5f, 1.5f));
}

void SimpleEnemy::update(float deltaTime)
{
    if (!isActive)
        return;
    
    moveTimer += deltaTime;
    position.x += directionX * speed * deltaTime;
    
    if (position.x < 50.0f || position.x > 750.0f)
    {
        directionX *= -1.0f;
    }
    
    position.y += sin(moveTimer * 3.0f) * 30.0f * deltaTime;
    
    sprite.setPosition(position);
    
    if (directionX < 0)
        sprite.setScale(Vector2f(-1.5f, 1.5f));
    else
        sprite.setScale(Vector2f(1.5f, 1.5f));
}

void SimpleEnemy::draw(RenderWindow& window)
{
    if (isActive)
    {
        window.draw(sprite);
    }
}

MushroomEnemy2::MushroomEnemy2(float x, float y)
    : Enemy(x, y, 3, 40), jumpTimer(0.0f), jumpInterval(1.8f + (rand()%100)/100.0f), onGround(true)
{
    if (texture.loadFromFile("c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/99003.png"))
        sprite = Sprite(texture);
    else
        sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(12, 12));
    sprite.setScale(Vector2f(1.6f, 1.6f));
}

void MushroomEnemy2::update(float deltaTime)
{
    if (!isActive) return;
    jumpTimer += deltaTime;
    if (onGround && jumpTimer >= jumpInterval)
    {
        velocity.y = -320.0f;
        onGround = false;
        jumpTimer = 0.0f;
    }
    if (!onGround)
    {
        velocity.y += 900.0f * deltaTime; // gravity
        position.y += velocity.y * deltaTime;
        if (position.y >= 500.0f)
        {
            position.y = 500.0f;
            velocity.y = 0.0f;
            onGround = true;
        }
    }
    sprite.setPosition(position);
}

void MushroomEnemy2::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}

FlowerEnemy2::FlowerEnemy2(float x, float y)
    : Enemy(x, y, 4, 30)
{
    if (texture.loadFromFile("c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/101193.png"))
        sprite = Sprite(texture);
    else
        sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(16, 24));
    sprite.setScale(Vector2f(1.5f, 1.5f));
}

void FlowerEnemy2::update(float deltaTime)
{
    if (!isActive) return;
    // Stationary; could shoot in later iteration
    sprite.setPosition(position);
}

void FlowerEnemy2::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}

ToothyEnemy::ToothyEnemy(float x, float y)
    : Enemy(x, y, 6, 60), hideTimer(0.0f), hideInterval(2.5f + (rand()%100)/100.0f), hidden(true)
{
    if (texture.loadFromFile("c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/99298.png"))
        sprite = Sprite(texture);
    else
        sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(12, 12));
    sprite.setScale(Vector2f(1.6f, 1.6f));
}

void ToothyEnemy::update(float deltaTime)
{
    if (!isActive) return;
    hideTimer += deltaTime;
    if (hidden && hideTimer >= hideInterval)
    {
        // pop out and lunge
        hidden = false;
        velocity.y = -300.0f;
        velocity.x = (rand()%2==0) ? -120.0f : 120.0f;
        hideTimer = 0.0f;
    }
    if (!hidden)
    {
        velocity.y += 900.0f * deltaTime;
        position.x += velocity.x * deltaTime;
        position.y += velocity.y * deltaTime;
        if (position.y >= 500.0f)
        {
            position.y = 500.0f;
            velocity.x = 0.0f;
            hidden = true;
            hideTimer = 0.0f;
        }
    }
    sprite.setPosition(position);
}

void ToothyEnemy::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}

BlueberryEnemy::BlueberryEnemy(float x, float y)
    : Enemy(x, y, 2, 20), speed(40.0f), moveDir(1.0f)
{
    sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(10, 10));
    sprite.setScale(Vector2f(1.4f, 1.4f));
}

void BlueberryEnemy::update(float deltaTime)
{
    if (!isActive) return;
    position.x += moveDir * speed * deltaTime;
    if (position.x < 60.0f || position.x > 1220.0f) moveDir *= -1.0f;
    sprite.setPosition(position);
}

void BlueberryEnemy::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}

DaisyEnemy::DaisyEnemy(float x, float y)
    : Enemy(x, y, 1, 10)
{
    sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(10, 10));
    sprite.setScale(Vector2f(1.3f, 1.3f));
}

void DaisyEnemy::update(float deltaTime)
{
    if (!isActive) return;
    // Slow walk after dropping in (if spawned from sky, spawn position will already set)
    sprite.setPosition(position);
}

void DaisyEnemy::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}

AcornMakerEnemy::AcornMakerEnemy(float x, float y)
    : Enemy(x, y, 12, 200), spawnTimer(0.0f), spawnInterval(3.0f + (rand()%200)/100.0f)
{
    sprite = Sprite(*getDummyTexture());
    sprite.setOrigin(Vector2f(20, 20));
    sprite.setScale(Vector2f(2.0f, 2.0f));
}

void AcornMakerEnemy::update(float deltaTime)
{
    if (!isActive) return;
    spawnTimer += deltaTime;
    // Spawning actual acorn enemies is handled by Game::spawnEnemy in this simple integration.
    sprite.setPosition(position);
}

void AcornMakerEnemy::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}
