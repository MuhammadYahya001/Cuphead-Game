#include "Peashooter.h"
#include <cmath>

Peashooter::Peashooter()
    : Weapon(10.0f, 5.0f) // Increased fire rate from 6 to 10 shots per second
{
}

Projectile* Peashooter::fire(float x, float y, float directionX, float directionY)
{
    if (!canFireFlag)
    {
        return nullptr;
    }
    
    float len = sqrt(directionX * directionX + directionY * directionY);
    if (len > 0.01f)
    {
        directionX /= len;
        directionY /= len;
    }
    else
    {
        directionX = 1.0f;
        directionY = 0.0f;
    }
    
    float velX = directionX * 500.0f;
    float velY = directionY * 500.0f;
    
    canFireFlag = false;
    timeSinceLastShot = 0.0f;
    
    return new Projectile(x, y, velX, velY, damage, 3.0f, false);
}

Projectile* Peashooter::fireEX(float x, float y, float directionX, float directionY)
{
    float len = sqrt(directionX * directionX + directionY * directionY);
    if (len > 0.01f)
    {
        directionX /= len;
        directionY /= len;
    }
    else
    {
        directionX = 1.0f;
        directionY = 0.0f;
    }
    
    float velX = directionX * 400.0f;
    float velY = directionY * 400.0f;
    
    return new Projectile(x, y, velX, velY, damage * 4.0f, 4.0f, true);
}
