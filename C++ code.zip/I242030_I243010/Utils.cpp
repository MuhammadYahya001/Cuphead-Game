#include "Utils.h"

using namespace sf;

Texture* getDummyTexture()
{
    static Texture* dummy = nullptr;
    if (!dummy)
    {
        dummy = new Texture();
    }
    return dummy;
}

SoundBuffer* getDummyBuffer()
{
    static SoundBuffer* dummy = nullptr;
    if (!dummy)
    {
        dummy = new SoundBuffer();
    }
    return dummy;
}

Font* getDummyFont()
{
    static Font* dummy = nullptr;
    if (!dummy)
    {
        dummy = new Font();
    }
    return dummy;
}
