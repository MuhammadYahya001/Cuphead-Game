#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

sf::Texture* getDummyTexture();
sf::SoundBuffer* getDummyBuffer();
sf::Font* getDummyFont();
