#include "AcornEnemy.h"
#include <string>
#include <cstdio>
#include <cmath>

using namespace sf;
using namespace std;

// Static member definitions
Texture* AcornEnemy::flyFrames = nullptr;
Texture* AcornEnemy::dropFrames = nullptr;
Texture* AcornEnemy::fallFrames = nullptr;
int AcornEnemy::flyFrameCount = 0;
int AcornEnemy::dropFrameCount = 0;
int AcornEnemy::fallFrameCount = 0;
bool AcornEnemy::texturesLoaded = false;
SoundBuffer* AcornEnemy::flyBuffer = nullptr;
SoundBuffer* AcornEnemy::dropBuffer = nullptr;
Sound* AcornEnemy::flySound = nullptr;
Sound* AcornEnemy::dropSound = nullptr;

void AcornEnemy::loadResources()
{
    if (texturesLoaded) return;
    
    string basePath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/ForestFolliesResources/resources/Aggravating Acorn/";
    string audioPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Audios-20251125T150841Z-1-001/Audios/";
    char path[512];
    
    // Load fly frames
    flyFrames = new Texture[MAX_FLY_FRAMES];
    flyFrameCount = 0;
    for (int i = 1; i <= MAX_FLY_FRAMES; i++)
    {
        snprintf(path, sizeof(path), "%sFly/acorn_fly_%04d.png", basePath.c_str(), i);
        if (flyFrames[flyFrameCount].loadFromFile(path))
            flyFrameCount++;
    }
    
    // Load drop frames (from Drop folder)
    dropFrames = new Texture[MAX_DROP_FRAMES];
    dropFrameCount = 0;
    for (int i = 1; i <= MAX_DROP_FRAMES; i++)
    {
        snprintf(path, sizeof(path), "%sDrop/acorn_drop_%04d.png", basePath.c_str(), i);
        if (dropFrames[dropFrameCount].loadFromFile(path))
            dropFrameCount++;
    }
    
    // Load fall frames (from Fall folder, they're named acorn_drop_0004 onwards)
    fallFrames = new Texture[MAX_FALL_FRAMES];
    fallFrameCount = 0;
    for (int i = 4; i <= 17; i++)
    {
        snprintf(path, sizeof(path), "%sFall/acorn_drop_%04d.png", basePath.c_str(), i);
        if (fallFrames[fallFrameCount].loadFromFile(path))
            fallFrameCount++;
    }
    
    // Load sounds
    flyBuffer = new SoundBuffer();
    if (flyBuffer->loadFromFile(audioPath + "sfx_platforming_forest_acorn_fly_loop.wav"))
    {
        flySound = new Sound(*flyBuffer);
    }
    
    dropBuffer = new SoundBuffer();
    if (dropBuffer->loadFromFile(audioPath + "sfx_platforming_forest_acorn_drop_01.wav"))
    {
        dropSound = new Sound(*dropBuffer);
    }
    
    texturesLoaded = true;
}

AcornEnemy::AcornEnemy(float x, float y, float playerX)
    : Enemy(x, y, 1, 20), currentState(FLYING), flyTimer(0.0f), 
      horizontalSpeed(150.0f), targetX(playerX), currentFrame(0), animTimer(0.0f), animSpeed(0.08f)
{
    loadResources();
    
    // Set initial sprite
    if (flyFrameCount > 0)
    {
        sprite = Sprite(flyFrames[0]);
        Vector2u size = flyFrames[0].getSize();
        sprite.setOrigin(Vector2f(size.x / 2.0f, size.y / 2.0f));
        sprite.setScale(Vector2f(0.8f, 0.8f));
    }
    else
    {
        sprite = Sprite(*getDummyTexture());
        sprite.setColor(Color(139, 90, 43)); // Brown color for acorn
    }
    
    // Start fly sound
    if (flySound)
    {
        flySound->play();
    }
}

void AcornEnemy::updatePlayerPosition(float playerX)
{
    targetX = playerX;
}

void AcornEnemy::update(float deltaTime)
{
    if (!isActive) return;
    
    flyTimer += deltaTime;
    animTimer += deltaTime;
    
    switch (currentState)
    {
        case FLYING:
        {
            // Move horizontally towards player
            if (position.x > targetX + 20)
            {
                position.x -= horizontalSpeed * deltaTime;
            }

            else if (position.x < targetX - 20)
            {
                position.x += horizontalSpeed * deltaTime;
            }

            // Flip sprite to face player
            float scaleX = abs(sprite.getScale().x);
            float scaleY = sprite.getScale().y;
            if (position.x < targetX) 
                sprite.setScale(Vector2f(-scaleX, scaleY)); // Face Right
            else
                sprite.setScale(Vector2f(scaleX, scaleY));  // Face Left
            
            // Check if above player (within range to drop)
            if (abs(position.x - targetX) < 50.0f)
            {
                // Start dropping!
                currentState = DROPPING;
                currentFrame = 0;
                animTimer = 0.0f;
                velocity.y = 50.0f;
                
                // Stop fly sound, play drop sound
                if (flySound) flySound->stop();
                if (dropSound) dropSound->play();
            }
            
            // Animate fly
            if (flyFrameCount > 0 && animTimer >= animSpeed)
            {
                animTimer = 0.0f;
                currentFrame = (currentFrame + 1) % flyFrameCount;
                sprite.setTexture(flyFrames[currentFrame]);
            }
            break;
        }
        
        case DROPPING:
        {
            // Short pause before falling
            position.y += velocity.y * deltaTime;
            velocity.y += 200.0f * deltaTime;
            
            // Animate drop
            if (dropFrameCount > 0 && animTimer >= animSpeed)
            {
                animTimer = 0.0f;
                currentFrame++;
                if (currentFrame >= dropFrameCount)
                {
                    currentState = FALLING;
                    currentFrame = 0;
                }
                else
                {
                    sprite.setTexture(dropFrames[currentFrame]);
                }
            }
            break;
        }
        
        case FALLING:
        {
            // Fall fast!
            position.y += velocity.y * deltaTime;
            velocity.y += 1200.0f * deltaTime;  // Fast gravity
            
            // Animate fall
            if (fallFrameCount > 0 && animTimer >= animSpeed * 0.5f)
            {
                animTimer = 0.0f;
                currentFrame = (currentFrame + 1) % fallFrameCount;
                sprite.setTexture(fallFrames[currentFrame]);
            }
            
            // Destroy when hits ground
            if (position.y >= 600.0f)
            {
                isActive = false;
            }
            break;
        }
    }
    
    // Go off-screen left/right = destroy
    if (position.x < -100 || position.x > 2000)
    {
        isActive = false;
        if (flySound) flySound->stop();
    }
    
    sprite.setPosition(position);
}

void AcornEnemy::draw(RenderWindow& window)
{
    if (isActive) window.draw(sprite);
}
