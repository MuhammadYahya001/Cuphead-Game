#pragma once
#include "Enemy.h"

class SimpleEnemy : public Enemy
{
private:
    float speed;
    float directionX;
    float moveTimer;
    
public:
    SimpleEnemy(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class MushroomEnemy2 : public Enemy
{
private:
    float jumpTimer;
    float jumpInterval;
    bool onGround;
public:
    MushroomEnemy2(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class FlowerEnemy2 : public Enemy
{
public:
    FlowerEnemy2(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class ToothyEnemy : public Enemy
{
private:
    float hideTimer;
    float hideInterval;
    bool hidden;
public:
    ToothyEnemy(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class BlueberryEnemy : public Enemy
{
private:
    float speed;
    float moveDir;
public:
    BlueberryEnemy(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class DaisyEnemy : public Enemy
{
public:
    DaisyEnemy(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};

class AcornMakerEnemy : public Enemy
{
private:
    float spawnTimer;
    float spawnInterval;
public:
    AcornMakerEnemy(float x, float y);
    void update(float deltaTime) override;
    void draw(sf::RenderWindow& window) override;
};
