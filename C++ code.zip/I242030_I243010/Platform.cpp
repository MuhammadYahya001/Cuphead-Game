#include "Platform.h"
#include <string>
#include <cstdio>

using namespace std;

Platform::Platform(float x, float y, float width, float height, int type)
    : position(x, y), size(width, height), isActive(true), obstacleType(type),
      sprite(*getDummyTexture())
{
    string resourcesPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/";
    
    // Load obstacle image based on type (1-11)
    char path[512];
    snprintf(path, sizeof(path), "%sBackground/Obstacle (%d).jpg", resourcesPath.c_str(), obstacleType);
    
    if (texture.loadFromFile(path))
    {
        sprite = Sprite(texture);
        // Scale texture to fit the specified size
        Vector2u texSize = texture.getSize();
        if (texSize.x > 0 && texSize.y > 0)
        {
            float scaleX = width / (float)texSize.x;
            float scaleY = height / (float)texSize.y;
            sprite.setScale(Vector2f(scaleX, scaleY));
        }
    }
    else
    {
        sprite = Sprite(*getDummyTexture());
        sprite.setScale(Vector2f(width / 32.0f, height / 32.0f));
    }
    
    sprite.setPosition(position);
}

void Platform::draw(RenderWindow& window)
{
    if (isActive)
    {
        window.draw(sprite);
    }
}

FloatRect Platform::getBounds() const
{
    return FloatRect(position, size);
}

bool Platform::getIsActive() const
{
    return isActive;
}

void Platform::setActive(bool active)
{
    isActive = active;
}
