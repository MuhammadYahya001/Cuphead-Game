#pragma once
#include "Weapon.h"

class Peashooter : public Weapon
{
public:
    Peashooter();
    Projectile* fire(float x, float y, float directionX, float directionY) override;
    Projectile* fireEX(float x, float y, float directionX, float directionY) override;
};
