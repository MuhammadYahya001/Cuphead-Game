#include "Boss.h"

Boss::Boss(float x, float y)
    : Enemy(x, y, 50, 500), attackTimer(0.0f), attackCooldown(2.0f), attackPhase(1)
{
    maxHealth = 50;
    health = 50;
    
    if (texture.loadFromFile("c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/Cuphead_ Don't Deal With the Devil! - PC _ Computer - The Spriters Resource_files/161265.png"))
    {
        sprite = Sprite(texture);
    }
    else
    {
        sprite = Sprite(*getDummyTexture());
    }
    sprite.setOrigin(Vector2f(32, 32));
    sprite.setScale(Vector2f(2.0f, 2.0f));
}

void Boss::update(float deltaTime)
{
    if (!isActive)
        return;
    
    attackTimer += deltaTime;
    if (attackTimer >= attackCooldown)
    {
        performAttack();
        attackTimer = 0.0f;
        attackCooldown = 1.5f + (rand() % 100) / 100.0f;
    }
    
    position.y += sin(attackTimer * 2.0f) * 50.0f * deltaTime;
    sprite.setPosition(position);
    
    if (health < maxHealth)
    {
        int flash = (int)(attackTimer * 5.0f) % 2;
        sprite.setColor(flash == 0 ? Color::White : Color(255, 200, 200));
    }
    else
    {
        sprite.setColor(Color::White);
    }
}

void Boss::draw(RenderWindow& window)
{
    if (isActive)
    {
        window.draw(sprite);
    }
}

void Boss::takeDamage(int damage)
{
    Enemy::takeDamage(damage);
    if (health <= maxHealth / 2 && attackPhase == 1)
    {
        attackPhase = 2;
        attackCooldown = 1.0f;
    }
}

void Boss::performAttack()
{
    // Attack logic handled by Game class
}
