#include "Projectile.h"
#include <string>
#include "Utils.h"

using namespace std;

Projectile::Projectile()
    : position(0, 0), velocity(0, 0), damage(0), lifetime(0), 
      maxLifetime(10.0f), isActive(false), isEX(false),
      sprite(*getDummyTexture())
{
    // Texture will be initialized when needed
}

Projectile::Projectile(float x, float y, float velX, float velY, float dmg, float maxLife, bool ex)
    : position(x, y), velocity(velX, velY), damage(dmg), 
      lifetime(0), maxLifetime(maxLife), isActive(true), isEX(ex),
      sprite(*getDummyTexture())
{
    // Use static textures so they're loaded once and shared by all projectiles
    static Texture* bulletTex = nullptr;
    static Texture* exBulletTex = nullptr;
    static bool texturesLoaded = false;
    
    if (!texturesLoaded)
    {
        string resourcesPath = "c:/Users/Lenovo/OneDrive/Desktop/FAST/BS-CYB SEM3 2025/OOP PROJECT/resources/";
        
        bulletTex = new Texture();
        if (!bulletTex->loadFromFile(resourcesPath + "Weapon/bullet.png"))
        {
            delete bulletTex;
            bulletTex = getDummyTexture();
        }
        
        exBulletTex = new Texture();
        if (!exBulletTex->loadFromFile(resourcesPath + "Weapon/EXbullet.png"))
        {
            delete exBulletTex;
            exBulletTex = getDummyTexture();
        }
        
        texturesLoaded = true;
    }
    
    // Use the appropriate shared texture
    Texture* texToUse = isEX ? exBulletTex : bulletTex;
    
    sprite = Sprite(*texToUse);
    Vector2u size = texToUse->getSize();
    if (size.x > 0 && size.y > 0)
    {
        sprite.setOrigin(Vector2f(size.x / 2.0f, size.y / 2.0f));
        sprite.setScale(Vector2f(0.5f, 0.5f));  // Scale down bullet for visibility
    }
    else
    {
        // If texture failed, make a colored placeholder visible
        sprite.setColor(Color(100, 180, 255, 255));
    }
    
    if (isEX)
    {
        sprite.setScale(Vector2f(1.5f, 1.5f));
    }
    else
    {
        sprite.setScale(Vector2f(1.0f, 1.0f));
    }
}

void Projectile::update(float deltaTime)
{
    if (!isActive)
        return;
    
    position.x += velocity.x * deltaTime;
    position.y += velocity.y * deltaTime;
    
    lifetime += deltaTime;
    if (lifetime >= maxLifetime)
    {
        isActive = false;
    }
    
    // Projectiles destroyed after traveling too far (no fixed screen bounds)
    // This allows them to exist in world coordinates with scrolling camera
    
    sprite.setPosition(position);
}

void Projectile::draw(RenderWindow& window)
{
    if (!isActive)
        return;
    
    window.draw(sprite);
}

bool Projectile::getIsActive() const
{
    return isActive;
}

void Projectile::setActive(bool active)
{
    isActive = active;
}

Vector2f Projectile::getPosition() const
{
    return position;
}

float Projectile::getDamage() const
{
    return damage;
}

FloatRect Projectile::getBounds() const
{
    return sprite.getGlobalBounds();
}

bool Projectile::getIsEX() const
{
    return isEX;
}
