#pragma once
#include "Projectile.h"

class Weapon
{
protected:
    float fireRate;
    float damage;
    float timeSinceLastShot;
    bool canFireFlag;
    
public:
    Weapon(float fireRate, float damage);
    virtual ~Weapon();
    
    virtual Projectile* fire(float x, float y, float directionX, float directionY) = 0;
    virtual Projectile* fireEX(float x, float y, float directionX, float directionY) = 0;
    virtual float getDamage() const;
    virtual float getFireRate() const;
    virtual void update(float deltaTime);
    bool canFire() const { return canFireFlag; }
    void resetFireTimer() { canFireFlag = false; timeSinceLastShot = 0.f; }
};
