#pragma once
#include <SFML/Graphics.hpp>
#include "Utils.h"

using namespace sf;

class Platform
{
private:
    Vector2f position;
    Vector2f size;
    Sprite sprite;
    Texture texture;
    bool isActive;
    int obstacleType; // 1-11 for different obstacle images
    
public:
    Platform(float x, float y, float width, float height, int type);
    
    void draw(RenderWindow& window);
    FloatRect getBounds() const;
    bool getIsActive() const;
    void setActive(bool active);
};
